public class NamingConflict {
    private String patientID;
    private String allergyNotes;
    
    public NamingConflict(String patientID, String allergyNotes) {
      
        this.patientID = patientID;
        this.allergyNotes = allergyNotes;
    }
}
